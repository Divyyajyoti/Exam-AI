def simplify(topic, context):
    prompt = f"""
Explain {topic} to a lazy college student
with 1 day before exam.

Use analogies and examples.
"""
