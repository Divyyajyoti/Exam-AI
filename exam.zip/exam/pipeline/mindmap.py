def generate_mindmap(topic, context):
    prompt = f"""
Create a structured mind map for {topic}.
Include:
- formulas
- tricks
- question types
"""
